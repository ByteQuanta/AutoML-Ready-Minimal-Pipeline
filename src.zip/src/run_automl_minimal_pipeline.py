from automl_minimal_pipeline import run_minimal_pipeline

filepath = "your_data_name.csv"
target_col = "dependant_variable"

results = run_minimal_pipeline(filepath, target_col)

print("Dropped features:", results["dropped_features"])
print("Best test split ratio:", results["best_test_size"])
print("Final F1 score:", results["best_f1"])

