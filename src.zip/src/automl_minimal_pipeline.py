# ============================================================
# AutoML Ready Minimal Pipeline
# ============================================================

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import optuna
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from statsmodels.stats.outliers_influence import variance_inflation_factor


SEED = 42
np.random.seed(SEED)


# ============================================================
#  1️⃣ Missing Value Analysis
# ============================================================
def missing_value_analysis(df):
    missing_summary = df.isnull().sum().sort_values(ascending=False)
    missing_percent = (df.isnull().sum() / len(df) * 100).sort_values(ascending=False)
    missing_df = pd.concat([missing_summary, missing_percent], axis=1, keys=['Missing Count', 'Missing %'])
    missing_df_filtered = missing_df[missing_df['Missing Count'] > 0]

    if missing_df_filtered.empty:
        print("✅ There are no missing values in the dataset.")
        return None
    else:
        print("⚠️ Variables with missing values:")
        display(missing_df_filtered.style.background_gradient(cmap='Reds', subset=['Missing %']))
        return missing_df_filtered


def handle_missing_values(df, strategy_num='median', strategy_cat='mode', verbose=True):
    df_filled = df.copy()
    num_cols = df_filled.select_dtypes(include=[np.number]).columns
    cat_cols = df_filled.select_dtypes(exclude=[np.number]).columns
    
    # Numeric imputation
    for col in num_cols:
        if df_filled[col].isnull().any():
            if strategy_num == 'median':
                fill_value = df_filled[col].median()
            elif strategy_num == 'mean':
                fill_value = df_filled[col].mean()
            else:
                fill_value = 0
            df_filled[col].fillna(fill_value, inplace=True)
            if verbose:
                print(f"🧩 Filled numeric column '{col}' with {strategy_num} ({fill_value:.3f})")
    
    # Categorical imputation
    for col in cat_cols:
        if df_filled[col].isnull().any():
            if strategy_cat == 'mode':
                fill_value = df_filled[col].mode()[0]
            else:
                fill_value = 'missing'
            df_filled[col].fillna(fill_value, inplace=True)
            if verbose:
                print(f"🧩 Filled categorical column '{col}' with {strategy_cat} ('{fill_value}')")
    
    print("✅ Missing value imputation completed.")
    return df_filled


# ============================================================
#  2️⃣ Duplicates
# ============================================================
def remove_duplicates(df, verbose=True):
    before = df.shape[0]
    df_clean = df.drop_duplicates().reset_index(drop=True)
    after = df_clean.shape[0]
    if verbose:
        print(f"✅ Removed {before - after} duplicate rows.")
    return df_clean


# ============================================================
#  3️⃣ VIF & Iterative Drop
# ============================================================
def calculate_vif(df, features):
    X = df[features].astype(float).copy()
    non_constant_cols = X.loc[:, X.std(axis=0) > 0].columns.tolist()
    vif_data = []
    for i, col in enumerate(non_constant_cols):
        try:
            vif = variance_inflation_factor(X[non_constant_cols].values, i)
        except Exception:
            vif = np.inf
        vif_data.append((col, vif))
    return pd.DataFrame(vif_data, columns=["feature", "VIF"]).sort_values("VIF", ascending=False)


def iterative_vif_drop(df, target_col=None, threshold=10.0, verbose=True):
    df_work = df.copy()
    features = [f for f in df_work.columns if f != target_col]
    dropped = []

    while True:
        vif_df = calculate_vif(df_work, features)
        if vif_df.empty:
            break

        top_feature, top_vif = vif_df.iloc[0]
        if verbose:
            print(f"Top VIF: {top_feature} = {top_vif:.3f}")

        if top_vif <= threshold:
            if verbose:
                print("✅ All VIF values below threshold.")
            break

        df_work.drop(columns=[top_feature], inplace=True)
        features.remove(top_feature)
        dropped.append(top_feature)
        if verbose:
            print(f"Dropped {top_feature}. Remaining: {len(features)} features.")

        if len(features) < 2:
            break

    final_vif = calculate_vif(df_work, features)
    return df_work, dropped, final_vif


# ============================================================
#  4️⃣ Correlation Matrix & Iterative Drop
# ============================================================
def calculate_corr(df, target_col=None, method='pearson', verbose=True):
    features = [col for col in df.columns if col != target_col]
    corr_matrix = df[features].corr(method=method).abs()
    np.fill_diagonal(corr_matrix.values, 0)

    # Extract upper triangle only to avoid duplicates
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))

    # Flatten correlation pairs
    high_corr_pairs = (
        upper.stack()
        .reset_index()
        .rename(columns={'level_0': 'feature_1', 'level_1': 'feature_2', 0: 'corr'})
        .sort_values(by='corr', ascending=False)
    )

    if verbose:
        print("Top correlated feature pairs:")
        display(high_corr_pairs.head(10))

    return corr_matrix, high_corr_pairs


def iterative_corr_drop(df, target_col=None, threshold=0.95, verbose=True):
    df_work = df.copy()
    features = [col for col in df_work.columns if col != target_col]
    dropped = []

    while True:
        corr_matrix = df_work[features].corr().abs()
        np.fill_diagonal(corr_matrix.values, 0)

        high_corr_pairs = np.where(corr_matrix > threshold)
        if len(high_corr_pairs[0]) == 0:
            if verbose:
                print("✅ All pairwise correlations below threshold.")
            break

        # Count how many high correlations each feature has
        corr_counts = (corr_matrix > threshold).sum(axis=1)
        to_drop = corr_counts.idxmax()

        dropped.append(to_drop)
        features.remove(to_drop)
        df_work.drop(columns=[to_drop], inplace=True)

        if verbose:
            print(f"🧹 Dropped '{to_drop}' (had {corr_counts[to_drop]} high correlations). Remaining: {len(features)}")

        if len(features) < 2:
            break

    return df_work, dropped


# ============================================================
#  5️⃣ Optimize Train/Test Split
# ============================================================
def optimize_test_split(X, y, metric="f1", n_trials=15, seed=42):
    results = []

    def objective(trial):
        test_size = trial.suggest_float("test_size", 0.1, 0.4)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, stratify=y, random_state=seed)
        pipe = Pipeline([
            ('scaler', RobustScaler()),
            ('clf', RandomForestClassifier(random_state=seed, n_jobs=-1))
        ])
        scores = cross_val_score(pipe, X_train, y_train, cv=3, scoring=metric, n_jobs=-1)
        score_mean = scores.mean()
        results.append((test_size, score_mean))
        return score_mean

    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=True)
    best_size = study.best_trial.params['test_size']

    print(f"✅ Best test ratio: {best_size:.3f}")
    print(f"📈 Best F1 score: {study.best_value:.4f}")

    return best_size, study.best_value


# ============================================================
#  6️⃣ Visualization
# ============================================================
def visualize_data(df, target_col=None, save_dir="plots"):
    os.makedirs(save_dir, exist_ok=True)
    print("📊 Generating visualizations...")

    numeric_df = df.select_dtypes(include=[np.number])
    if not numeric_df.empty:
        plt.figure(figsize=(10,8))
        sns.heatmap(numeric_df.corr(), cmap="coolwarm", center=0)
        plt.title("Correlation Heatmap")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, "correlation_heatmap.png"))
        plt.close()

        for col in numeric_df.columns:
            plt.figure(figsize=(6,3))
            sns.histplot(numeric_df[col], kde=True)
            plt.title(f"Distribution: {col}")
            plt.tight_layout()
            plt.savefig(os.path.join(save_dir, f"{col}_dist.png"))
            plt.close()

    if target_col and target_col in df.columns:
        plt.figure(figsize=(5,4))
        sns.countplot(x=df[target_col])
        plt.title("Target Distribution")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, "target_distribution.png"))
        plt.close()

    print(f"✅ Plots saved in '{save_dir}'")


# ============================================================
#  7️⃣ Main AutoML-like Wrapper (Corr + VIF sequential)
# ============================================================
def run_minimal_pipeline(filepath, target_col=None, save_cleaned=True, seed=SEED):
    print("\n🚀 Starting AutoML-style preprocessing pipeline...")

    df = pd.read_csv(filepath)
    print(f"Loaded data: {df.shape}")

    #  1️⃣ Missing values
    missing_value_analysis(df)
    df = handle_missing_values(df)

    #  2️⃣ Remove duplicates
    df = remove_duplicates(df)

    #  3️⃣ Prepare numeric data
    X = df.drop(columns=[target_col]) if target_col else df.copy()
    y = df[target_col] if target_col else None
    X_num = X.select_dtypes(include=[np.number])

    #  4️⃣ Iterative correlation cleanup
    print("\n🔹 Calculating correlation matrix...")
    _, high_corr_pairs = calculate_corr(X_num, target_col=target_col)

    print("\n🔹 Running iterative correlation cleanup...")
    corr_cleaned_df, corr_dropped = iterative_corr_drop(X_num, target_col=target_col, threshold=0.95)
    print(f"Dropped due to high correlation: {corr_dropped}")

    #  5️⃣ VIF cleaning (after correlation cleanup)
    print("\n🔹 Running VIF cleanup...")
    df_vif = pd.concat([corr_cleaned_df, y], axis=1) if y is not None else corr_cleaned_df
    cleaned_df, vif_dropped, final_vif = iterative_vif_drop(df_vif, target_col=target_col)
    print(f"Dropped due to multicollinearity (VIF): {vif_dropped}")

    # Combine dropped features info
    dropped = corr_dropped + vif_dropped

    if target_col and target_col in cleaned_df.columns:
        X_clean = cleaned_df.drop(columns=[target_col])
        y_clean = cleaned_df[target_col]
    else:
        X_clean, y_clean = cleaned_df, y

    #  6️⃣ Optimize split
    if y_clean is not None:
        print("\n🔹 Optimizing train/test split...")
        best_test_size, best_f1 = optimize_test_split(X_clean, y_clean)
    else:
        best_test_size, best_f1 = None, None

    #  7️⃣ Visualization
    visualize_data(cleaned_df, target_col=target_col)

    #  8️⃣ Save cleaned numeric data
    if save_cleaned:
        os.makedirs("results", exist_ok=True)
        out_path = "results/cleaned_numeric_corr_vif.csv"
        X_clean.to_csv(out_path, index=False)
        print(f"✅ Cleaned numeric data saved to '{out_path}'")

    print("\n🎯 Pipeline completed successfully.")
    return {
        "cleaned_df": cleaned_df,
        "dropped_features": dropped,
        "final_vif": final_vif,
        "best_test_size": best_test_size,
        "best_f1": best_f1
    }

